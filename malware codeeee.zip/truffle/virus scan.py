import tkinter as tk
from tkinter import filedialog

# Define malicious signatures (can be patterns, strings, etc.)
MALICIOUS_SIGNATURES = [b"virus", b"malware", b"trojan", b"hack"]

def scan_file(file_path):
    try:
        # Open the file for scanning in binary mode
        with open(file_path, 'rb') as file:
            content = file.read()
            
        # Check if any malicious signature is present in the file content
        for signature in MALICIOUS_SIGNATURES:
            if signature in content.lower():
                return True, signature.decode()
    except IOError:
        return False, None

    return False, None

def scan_selected_file():
    file_path = filedialog.askopenfilename()
    if file_path:
        is_infected, signature = scan_file(file_path)
        if is_infected:
            result_label.config(text=f"File is infected with '{signature}'.", fg="red")
        else:
            result_label.config(text="File is clean.", fg="green")

# Create the main window
root = tk.Tk()
root.title("File Scanner")

# Set window size and position
window_width = 400
window_height = 200
screen_width = root.winfo_screenwidth()
screen_height = root.winfo_screenheight()
x = (screen_width / 2) - (window_width / 2)
y = (screen_height / 2) - (window_height / 2)
root.geometry(f"{window_width}x{window_height}+{int(x)}+{int(y)}")

# Set window background color
root.config(bg="#f0f0f0")

# Create a frame for the content
frame = tk.Frame(root, padx=20, pady=20, bg="#f0f0f0")
frame.pack()

# Create a label for the instruction
instruction_label = tk.Label(frame, text="Select a file to scan:", font=("Arial", 12), bg="#f0f0f0")
instruction_label.pack()

# Create a button to upload file
upload_button = tk.Button(frame, text="Upload File", command=scan_selected_file, font=("Arial", 12), bg="#008CBA", fg="white")
upload_button.pack(pady=10)

# Create a label to display the result
result_label = tk.Label(root, text="", font=("Arial", 12), bg="#f0f0f0")
result_label.pack(pady=10)

# Run the main event loop
root.mainloop()
